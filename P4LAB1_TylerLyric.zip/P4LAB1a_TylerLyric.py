#Lyric Tyler
#July 04th, 2025
#P4 LAB1
#Use turtle and loops to create a square and triangle

#Import turtle
import turtle

#Create the turtle window and start drawing
win = turtle.Screen()
pen = turtle.Turtle()

#Set up the turtle options
pen.pensize(5)
pen.pencolor("purple")
pen.shape("arrow")

#Code the drawing of the shape
for side in range(4):
    pen.forward(100)
    pen.left(90)

#Execute a while loop that goes 3 times
sides = 3

while sides > 0:
    pen.forward(100)
    pen.left(120)
    sides = sides - 1

#Wait for the window to be closed
win.mainloop()
