#Lyric Tyler
#July 04th, 2025
#P4 LAB1
#Use turtle and loops to draw out your initials (LT)

#Import turtle
import turtle

#Create the turtle window and start drawing
win = turtle.Screen()
pen = turtle.Turtle()

#Set up the turtle options
pen.pensize(5)
pen.pencolor("purple")
pen.shape("arrow")

#Write out an L   
pen.setheading(270)
pen.forward(100)  
pen.left(90)  
pen.forward(50)  

#Write out a T  
pen.penup()  
pen.goto(50, 0)
pen.pendown()  
pen.forward(80)  
pen.backward(40)  
pen.right(90)  
pen.forward(100)  

#Wait for the window to be closed  
win.mainloop()  
